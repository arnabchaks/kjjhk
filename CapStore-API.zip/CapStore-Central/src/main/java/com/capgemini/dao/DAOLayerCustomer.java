package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.dto.CustomerAddress;
import com.capgemini.dto.CustomerOrders;
import com.capgemini.dto.Customers;
import com.capgemini.dto.Feedbacks;
import com.capgemini.dto.Products;
import com.capgemini.dto.WishList;
import com.capgemini.dto.feedbackdetails;
import com.capgemini.exception.CapStoreException;

public interface DAOLayerCustomer {
	// Cart Operations
	/*		public Carts addToCart(int productId, int customerId, int quantity, int merchantId);
			public Carts removeFromCart(int productId, int customerId);
			public Carts emptyCart(int cartId);
			public Carts saveCart(int cartId);
			public Carts retrieveCart(int customerId);
			*/
	// WishList Operations
			public WishList addToWishList(int productId, int customerId, int merchantId);
			public WishList removeFromWishList(int wishlistId);
			public WishList emptyWishList(int wishlistId);
			public WishList saveWishList(int wishlistId);
			public WishList retrieveWishList(int customerId);
			
			public Customers createAccount(Customers cusDTO) throws CapStoreException;
			public Boolean changePassword(String email_ID, String password, String newPassword);
			public Customers validateCustomerForLogin(Customers customer) throws CapStoreException;
			public List<Products> findAll();
			public String forgotPassword(String email_ID);
			
			public Feedbacks getFeedBack(Feedbacks feedback);
			public Customers findByEmailID(String email_ID) throws CapStoreException;
			public String check();
			List<CustomerAddress> getAddresses(int customerId);
			public Customers findByID(int ID);
			List<CustomerOrders> getOrders(int customerId);
			Customers getCustomer(int cid);
			void deleteCoupon(int cust_id, String code);
			feedbackdetails getfeedbackdetails(int id);
			ArrayList<Feedbacks> merchantFeedback(int mid);
			ArrayList<Feedbacks> productFeedback(int pid);
			ArrayList<Products> findSimilarProducts(int pid);
			void addFeedback(Feedbacks fb);
			Products findPById(Integer id);
			List<Products> findByCategory(Enum cat);
			void createReferralCoupon(int cid);
			String getStateFromPin(int pincode);
			String getCityFromPin(int pincode);
			void addAddress(CustomerAddress custAdd);
			CustomerAddress addAddressPinDetails(CustomerAddress custAdd) throws Exception;
}
