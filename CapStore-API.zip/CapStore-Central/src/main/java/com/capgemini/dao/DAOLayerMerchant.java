package com.capgemini.dao;

import java.util.List;

import com.capgemini.dto.Customers;
import com.capgemini.dto.Merchants;
import com.capgemini.dto.Products;
import com.capgemini.exception.CapStoreException;

public interface DAOLayerMerchant {
	
	//public boolean addProduct(Products product);

	Merchants findByEmailID(String email_ID);

	Merchants validateMerchantForLogin(Merchants merchant);

	Merchants addMerchant(Merchants merchant);

	void deleteMerchant(String[] ids);

	Merchants updateMerchant(Merchants merchant);

	Products addProduct(Products product);

	void deleteProduct(String[] ids);

	Products updateProduct(Products product);

	List<Merchants> getAllMerchant();

	List<Customers> getAllCustomer();

	List<Products> getAllProduct();

	List<Products> getAllProduct(int merchantId);

	boolean checkAvailabilty(Products product);

	boolean checkDeliveryAvailability(Products product, int pincode) throws CapStoreException;

	Products findById(int id);

	Merchants findByMId(Integer id);
	

}
