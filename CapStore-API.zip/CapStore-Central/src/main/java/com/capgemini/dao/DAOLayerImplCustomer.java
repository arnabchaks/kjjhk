package com.capgemini.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dto.Carts;
import com.capgemini.dto.Coupons;
import com.capgemini.dto.CustomerAddress;
import com.capgemini.dto.CustomerOrders;
import com.capgemini.dto.Customers;
import com.capgemini.dto.Feedbacks;
import com.capgemini.dto.Merchants;
import com.capgemini.dto.Pincodes;
import com.capgemini.dto.ProductCategory;
import com.capgemini.dto.Products;
import com.capgemini.dto.WishList;
import com.capgemini.dto.feedbackdetails;
import com.capgemini.exception.CapStoreException;

@Repository
@EnableTransactionManagement
public class DAOLayerImplCustomer implements DAOLayerCustomer {

	@PersistenceContext
	private EntityManager em;
	
	/*@Override
	@Transactional
	public Customers createAccount(Customers cusDTO) {
		em.persist(cusDTO);
		return em.find(Customers.class, cusDTO.getCustomerId());
	}*/
	
	@Override
	@Transactional
	public Customers createAccount(Customers cusDTO) throws CapStoreException {
		
		em.persist(cusDTO);
		if (cusDTO.getReferredby() != "" || cusDTO.getReferredby() != null) {
			if (em.find(Customers.class, Integer.parseInt(cusDTO.getReferredby())) != null) {
				createReferralCoupon(findByEmailID(cusDTO.getCustomerEmail()).getCustomerId());
				createReferralCoupon(Integer.parseInt(cusDTO.getReferredby()));
			}
		}
		return em.find(Customers.class, cusDTO.getCustomerId());
	}
	
	@Override
	public Customers validateCustomerForLogin(Customers customer) throws CapStoreException {
		System.out.println("inside daoimpl login check***");
		Customers check=findByEmailID(customer.getCustomerEmail());
		if(check.getCustomerPswd().equals(customer.getCustomerPswd()))
			return check;
		else
			return null;
		
	}
	//new Raju code
	/*@Override
	public Customers validateCustomerForLogin(Customers customer) throws CapStoreException {
		Customers check=findByEmailID(customer.getCustomerEmail());
		if(check.getCustomerPswd().equals(customer.getCustomerPswd()))
			return check;
		else
			throw new CapStoreException("Password doesnt match");
	}*/
	@Override
	@Transactional
	public void createReferralCoupon(int cid) {
		if (em.find(Customers.class, cid) != null) {
			String code = createCode();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			LocalDate localDate = LocalDate.parse(dtf.format(LocalDate.now().plusMonths(3)), dtf);
			Date date = java.sql.Date.valueOf(localDate);

			int amount = 200;
			Coupons coupon = new Coupons(code, date, amount, cid);
			em.persist(coupon);

		}

	}

	public String createCode() {
		String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		Random rnd = new Random();
		String code = null;
		StringBuilder sb = new StringBuilder("");
		while (sb.length() < 6) {
			double d = rnd.nextDouble();
			int index = (int) (d * CHARS.length());
			sb.append(CHARS.charAt(index));
			code = sb.toString();
		}
		return code;
	}
	
	@Override
	@Transactional
	public List<CustomerAddress> getAddresses(int customerId) {
		System.out.println("Entered");
		int a = customerId;
		System.out.println("a : " + a);
//		String sql="select add from CustomerAddress add where customer_ID=1";
		String sql="select add from CustomerAddress add where customer_ID= ?1";
//		TypedQuery<CustomerAddress> tq=em.createQuery(sql,CustomerAddress.class);
		System.out.println("2");
		Query query = em.createQuery(sql);
		query.setParameter(1, a);
//		query.setParameter("customerId", (int)customerId);
		List<CustomerAddress> lm = query.getResultList();
		System.out.println(lm);
		return lm;
	}

	/*@Override
	public Customers validateCustomerForLogin(Customers customer) throws CapStoreException {
		Customers check=findByEmailID(customer.getCustomerEmail());
		if(check.getCustomerPswd().equals(customer.getCustomerPswd()))
			return check;
		else
			throw new CapStoreException("Password doesnt match");
	}*/
	
	@Override
	@Transactional
	public List<CustomerOrders> getOrders(int customerId) {
		System.out.println("Entered");
		int a = customerId;
		System.out.println("a : " + a);
//		String sql="select add from CustomerAddress add where customer_ID=1";
		String sql="select order from CustomerOrders order where customer_ID= ?1";
//		TypedQuery<CustomerAddress> tq=em.createQuery(sql,CustomerAddress.class);
		System.out.println("2");
		Query query = em.createQuery(sql);
		query.setParameter(1, a);
//		query.setParameter("customerId", (int)customerId);
		List<CustomerOrders> lm = query.getResultList();
		System.out.println(lm);
		return lm;
	}



	
	@Override
	public Customers findByEmailID(String email_ID) throws CapStoreException {
		String sql="select customer from Customers customer where customer.customerEmail =:email" ;
		TypedQuery<Customers> tq=em.createQuery(sql,Customers.class);
		tq.setParameter("email", email_ID);
		try {
			return tq.getSingleResult();
		}
		catch (NoResultException exc) {
			throw new CapStoreException("Account not found");
		}
	}
	@Override
	public Customers findByID(int ID) {
		String sql="select customer from Customers customer where customer.customerId =:ID" ;
		TypedQuery<Customers> tq=em.createQuery(sql,Customers.class);
		tq.setParameter("ID", ID);
	
		return tq.getSingleResult();
		
	}
	@Override
	@Transactional
	public CustomerAddress addAddressPinDetails(CustomerAddress custAdd) throws Exception {
		try{
		Pincodes pincodes = (Pincodes) em.find(Pincodes.class, custAdd.getPincode());
		custAdd.setCity(pincodes.getCity());
		custAdd.setState(pincodes.getState());
		return custAdd;
		}catch(Exception e){
			throw e;
		}
		
	}
	@Override
	@Transactional
	public void addAddress(CustomerAddress custAdd){
		System.out.println("DAO: "+custAdd);
		em.persist(custAdd);
	}
	@Override
	@Transactional
	public String getCityFromPin(int pincode){
		try{
			Pincodes pincodes = (Pincodes) em.find(Pincodes.class, pincode);
			return pincodes.getCity();
			}catch(Exception e){
				throw e;
			}
	}
	@Override
	@Transactional
	public String getStateFromPin(int pincode){
		try{
			Pincodes pincodes = (Pincodes) em.find(Pincodes.class, pincode);
			return pincodes.getState();
			}catch(Exception e){
				throw e;
			}
	}
	@Override
	@Transactional
	public String check() {
		
		Products p=new Products();
		p.setProductCategory(ProductCategory.ELECTRONICS);
		//p.setProductId(103);
		p.setProductName("PocoF1");
		p.setProductPrice(25000);
		p.setProductQuantity(25);
		p.setProductRating(4);
		p.setTotalSold(10);
		Merchants m=new Merchants();
		m.setMerchantAddress("Delhi");
		m.setMerchantEmail("m2@gmail.com");
		m.setMerchantFlag(true);
		//m.setMerchantId(202);
		m.setMerchantMobile("7894561235");
		m.setMerchantName("A1Sales");
		m.setMerchantPswd("m2abcd");
		m.setMerchantRating(3);
		m.setMerchanttype("seller");
		List<Merchants> l1 = new ArrayList<>();
		l1.add(m);
		p.setMerchants(l1);
		em.persist(m);
		em.persist(p);
		return "hello";
		
		
		
	}
	@Override
	public Feedbacks getFeedBack(Feedbacks feedback) {
		return null;
	}
	/*@Override
	public List<Products> findAll() {
		// TODO Auto-generated method stub
		return null;
	}*/
	
	@Override
	public List<Products> findAll() {
		String sql="select product from Products product";
		TypedQuery<Products> tq=em.createQuery(sql,Products.class);
		List<Products> lm=tq.getResultList();
		return lm;
	}
	public Carts addToCart(int productId, int customerId, int quantity, int merchantId) {
		// TODO Auto-generated method stub
		return null;
	}
	public Carts removeFromCart(int productId, int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	public Carts emptyCart(int cartId) {
		int i=1;
		return null;
	}
	public Carts saveCart(int cartId) {
		// TODO Auto-generated method stub
		return null;
	}
	public Carts retrieveCart(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	public WishList addToWishList(int productId, int customerId, int merchantId) {
		// TODO Auto-generated method stub
		return null;
	}
	public WishList removeFromWishList(int wishlistId) {
		// TODO Auto-generated method stub
		return null;
	}
	public WishList emptyWishList(int wishlistId) {
		// TODO Auto-generated method stub
		return null;
	}
	public WishList saveWishList(int wishlistId) {
		// TODO Auto-generated method stub
		return null;
	}
	public WishList retrieveWishList(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String forgotPassword(String email_ID) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Boolean changePassword(String email_ID, String password, String newPassword) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<Products> findByCategory(Enum cat) {
		String sql="select product from Products product where productCategory=:cat";
		TypedQuery<Products> tq=em.createQuery(sql,Products.class);
		tq.setParameter("cat", cat);
		List<Products> lm=tq.getResultList();
		return lm;
	}

	@Override
	public Products findPById(Integer id) {
		
			String sql="select pd from Products pd where pd.productId =:id" ;
			TypedQuery<Products> tq=em.createQuery(sql,Products.class);
			tq.setParameter("id", id);
			
			return tq.getSingleResult();
		
	}

	@Override
	@Transactional
	public void addFeedback(Feedbacks fb) {
		
		em.persist(fb);
		Products pUpdate=em.find(Products.class, fb.getProductId());
		pUpdate.setProductRating(getfeedbackdetails(pUpdate.getProductId()).getAvg());
		em.persist(pUpdate);
		
	}
	
	@Override
	public ArrayList<Products> findSimilarProducts(int pid) {
		Products p = findPById(pid);
		String s = "select p from Products p where p.productCategory= ?1 and p.productPrice between ?2 and ?3 and p.productRating between ?4 and ?5 and p.productId <> ?6";
		TypedQuery<Products> query=em.createQuery(s,Products.class);
		query.setParameter(1, p.getProductCategory());
		query.setParameter(2, 0.4*p.getProductPrice());
		query.setParameter(3, 1.6*p.getProductPrice());

		query.setParameter(4, p.getProductRating() - 1);
		query.setParameter(5, p.getProductRating() + 1);
		query.setParameter(6, p.getProductId());
		ArrayList<Products> list = (ArrayList<Products>) query.getResultList();
		System.out.println("executed....");
		return list;
	}

	@Override
	public ArrayList<Feedbacks> productFeedback(int pid) {
		// TODO Auto-generated method stub
		System.out.println("---abcd----");
		String s = "select f from Feedbacks f where f.productId= ?1";
		
		TypedQuery<Feedbacks> query=em.createQuery(s,Feedbacks.class);
		System.out.println("---pqrs----");
		query.setParameter(1, pid);
		ArrayList<Feedbacks> list = (ArrayList<Feedbacks>) query.getResultList();
		System.out.println("---ijkl----");

		return list;
	}
	@Override
	public ArrayList<Feedbacks> merchantFeedback(int mid) {
		System.out.println("---efgh----");
		String s = "select f from feedbacks f where f.merchantId= ?1";
		
		TypedQuery<Feedbacks> query=em.createQuery(s,Feedbacks.class);
		
		query.setParameter(1, mid);
		
		ArrayList<Feedbacks> list = (ArrayList<Feedbacks>) query.getResultList();
		System.out.println("---mnop----");
		return list;
	}
	
	@Override
	public feedbackdetails getfeedbackdetails(int id) {
		feedbackdetails f=new feedbackdetails();
		//String check=splitFeedbackType(id);
		String s = null;
		String s1 = null;
		/*if(check.equals("merchant")){
			s = "select count(f.feedbackId) from feedbacks f where f.merchantId= ?1";
			s1 = "select count(f.feedbackId) from feedbacks f where f.merchantId= ?1 and f.feedbackRating= ?2";
			
		}*/
		/*else if(check.equals("product")){*/
			s = "select count(f.feedbackId) from Feedbacks f where f.productId= ?1";
			s1 = "select count(f.feedbackId) from Feedbacks f where f.productId= ?1 and f.feedbackRating= ?2";
			
		/*}*/
		TypedQuery<Long> q=em.createQuery(s,Long.class);
			
		q.setParameter(1, id);
		f.setTotal((Long) q.getSingleResult());
		
		TypedQuery<Long> q5 = em.createQuery(s1,Long.class);
		q5.setParameter(1, id);
		q5.setParameter(2,5.0);
		f.setStar5((Long) q5.getSingleResult());
		
		TypedQuery<Long> q4 = em.createQuery(s1,Long.class);
		q4.setParameter(1, id);
		q4.setParameter(2,4.0);
		f.setStar4((Long) q4.getSingleResult());
		
		TypedQuery<Long> q3 = em.createQuery(s1,Long.class);
		q3.setParameter(1, id);
		q3.setParameter(2,3.0);
		f.setStar3((Long) q3.getSingleResult());
		
		TypedQuery<Long> q2 = em.createQuery(s1,Long.class);
		q2.setParameter(1, id);
		q2.setParameter(2,2.0);
		f.setStar2((Long) q2.getSingleResult());
		
		TypedQuery<Long> q1 = em.createQuery(s1,Long.class);
		q1.setParameter(1, id);
		q1.setParameter(2,1.0);
		f.setStar1((Long) q1.getSingleResult());
		
		f.calculatePercent();
		
		System.out.println(f.getStar3()+"-----"+f.getStar4()+"#####"+f.getAvg());
		return f;
	}
	
	public String splitFeedbackType(int id) {
		// TODO Auto-generated method stub
		if (id < 30001 && id > 20000)
			return "merchant";
		else if (id < 40001 && id > 30000)
			return "product";
		else
			return null;
	}
	


	@Override
	public Customers getCustomer(int cid) {
		return em.find(Customers.class, cid);
	}

	@Override
	@Transactional
	public void deleteCoupon(int cust_id, String code) {
		String s = "select c from coupons c where c.couponCode= :id";
		Query q = em.createQuery(s);
		q.setParameter("id", code);
		Coupons c = (Coupons) q.getSingleResult();
		System.out.println(c.getCustomerId());
		if (c.getCustomerId() == cust_id) {
			s = "delete from coupons c where c.coupon_code= :id";
			Query query = em.createQuery(s);
			query.setParameter("id", code);
			query.executeUpdate();

		}
	}
}
