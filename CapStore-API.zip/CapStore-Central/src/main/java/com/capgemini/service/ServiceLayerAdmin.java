package com.capgemini.service;

import com.capgemini.dto.Admin;
import com.capgemini.dto.Coupons;

public interface ServiceLayerAdmin {

	public Admin findById(int id);
	public Admin validateAdmin(Admin admin);
	
	public Coupons addCoupon(Coupons c);
}
