package com.capgemini.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.DAOLayer;
import com.capgemini.dao.DAOLayerAdmin;
import com.capgemini.dao.DAOLayerCustomer;
import com.capgemini.dao.DAOLayerMerchant;
import com.capgemini.dto.Admin;
import com.capgemini.dto.Carts;
import com.capgemini.dto.CustomerAddress;
import com.capgemini.dto.CustomerOrders;
import com.capgemini.dto.Customers;
import com.capgemini.dto.Feedbacks;
import com.capgemini.dto.Merchants;
import com.capgemini.dto.ProductCategory;
import com.capgemini.dto.Products;
import com.capgemini.dto.feedbackdetails;
import com.capgemini.exception.CapStoreException;

@Service
public class ServiceLayerImpl implements ServiceLayer
{
	@Autowired
	private DAOLayer daoref;
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	private DAOLayerAdmin daorefAdmin;
	@Autowired
	private DAOLayerCustomer daorefCustomer;
	@Autowired
	private DAOLayerMerchant daorefMerchant;
	@Override
	public Admin validateAdmin(Admin admin)
	{
		return daoref.validateAdmin(admin);
	}

	
	@Override
	public Admin findById(int id) {
		return daoref.findById(id);
	}


	/*@Override
	public Customers createAccount(Customers cusDTO) {
		return daoref.createAccount(cusDTO);
	}*/
	
	@Override
	public Customers createAccount(Customers cusDTO) {
		
		List<Customers> listOfCustomers=daoref.getAllCustomer();
		
		for (Customers c:listOfCustomers) {
			if(cusDTO.getCustomerEmail().equals(c.getCustomerEmail()))
			{
				Customers cnew = new Customers();
				cnew.setCustomerName("Dummy");
				return cnew;
				
			}
				
			else if(cusDTO.getCustomerMobile().equals(c.getCustomerMobile()))
			{
				Customers cnew2 = new Customers();
				cnew2.setCustomerName("Dummy");
				return cnew2;
				
			}
		}
		
		 return daoref.createAccount(cusDTO);
		
	}



	@Override
	public Customers validateCustomerForLogin(Customers customer) throws CapStoreException {
		return daorefCustomer.validateCustomerForLogin(customer);
	}


	@Override
	public String check() {
		return daoref.check();
	}

	@Override
	public List<Products> findAll() {
		String sql="select product from Products product";
		TypedQuery<Products> tq=em.createQuery(sql,Products.class);
		List<Products> lm=tq.getResultList();
		return lm;
	}


	@Override
	public List<CustomerAddress> getAddresses(int customerId) {
		System.out.println("Service");
		return daorefCustomer.getAddresses(customerId);
	}
	@Override
	public Customers findCById(int id) {
		return daorefCustomer.findByID(id);
	}
	
	@Override
	public Products findPById(int id) {
		String sql="select pd from Products pd where pd.productId =:id" ;
		TypedQuery<Products> tq=em.createQuery(sql,Products.class);
		tq.setParameter("id", id);
		
		return tq.getSingleResult();
	}

	@Override
	public List<Products> findByCategory(Enum cat) {
		
		String sql="select product from Products product where productCategory=:cat";
		TypedQuery<Products> tq=em.createQuery(sql,Products.class);
		tq.setParameter("cat", cat);
		List<Products> lm=tq.getResultList();
		return lm;
	}


	@Override
	public List<CustomerOrders> getOrders(Integer cust) {
		
		return daorefCustomer.getOrders(cust);
	}

	@Override
	public List<Products> customerSearch(String productName, String cat) {
		
		Query query;
		
		if(cat.equals("all")) {
			query = em.createQuery("Select p from Products p");
		}
		else {
			query = em.createQuery("Select p from Products p where productCategory = ?1");
			ProductCategory category = ProductCategory.valueOf(cat.toUpperCase());
			query.setParameter(1, category);
		}
		
		List<Products> searchList = query.getResultList();
		
		if(productName.equals(""))
			return searchList;
		
		Iterator<Products> it = searchList.iterator();

		while (it.hasNext()){
			Products p = it.next();
			int flag=0;
			String name = p.getProductName();
			String nameArr[] = name.split(" ");
			String queryArray[] = productName.split(" ");
			for(String iter: nameArr){
				for(String iter2: queryArray){
					if(iter.equalsIgnoreCase(iter2)){
						flag++;
						break;
					}
				}
			}
			if(flag==0) it.remove();
		}

		Collections.sort(searchList, new Comparator<Products>(){
			
			public int compare(Products o1, Products o2) {
				if((o1.getProductName().contains(productName))&&(o2.getProductName().contains(productName))){
					return o2.getProductName().length() - o1.getProductName().length();
				}
				else if((o1.getProductName().contains(productName))&&(!o2.getProductName().contains(productName))){
					return 1;
				}
				else if((!o1.getProductName().contains(productName))&&(o2.getProductName().contains(productName))){
					return -1;
				}
				else if((!o1.getProductName().contains(productName))&&(!o2.getProductName().contains(productName))){
					int flag1 = 0;
					int flag2 = 0;
					String name1 = o1.getProductName();
					String name2 = o2.getProductName();
					String name1Arr[] = name1.split(" ");
					String name2Arr[] = name2.split(" ");
					String queryArray[] = productName.split(" ");
					for(String iter: name1Arr){
						for(String iter2: queryArray){
							if(iter.equals(iter2)){
								flag1++;
							}
						}
					}
					
					for(String iter: name2Arr){
						for(String iter2: queryArray){
							if(iter.equals(iter2)){
								flag2++;
							}
						}
					}
					if(flag1>flag2) return 1;
					else return -1;
				}
				else return 1;
			}
		
		});
		
		return searchList;
	}
	@Override
	public Boolean addAddress(CustomerAddress custAdd){
		try{
		custAdd = daorefCustomer.addAddressPinDetails(custAdd);
		daorefCustomer.addAddress(custAdd);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	@Override
	public String getCityFromPin(int pincode){
		try{
			return daorefCustomer.getCityFromPin(pincode);
		}catch(Exception e){
			return null;
		}
	}
	@Override
	public String getStateFromPin(int pincode){
		try{
			return daorefCustomer.getStateFromPin(pincode);
		}catch(Exception e){
			return null;
		}
	}
	
	@Override
	public List<Products> getAllProduct() {
		return daoref.getAllProduct();
	}


	@Override
	public Merchants validateMerchantForLogin(Merchants merchant) {
		return daoref.validateMerchantForLogin(merchant);
	}


	@Override
	public Products findProduct(int id) {
		return daoref.findProduct(id);
	}


	@Override
	public Carts addToCart(Carts cart) {
		return daoref.addToCart(cart);
	}


	@Override
	public Carts updateQuantity(Integer csn) {
		return daoref.updateQuantity(csn);
	}


	@Override
	public Carts deleteFromCart(Carts cart) {
		return daoref.deleteFromCart(cart);
	}


	@Override
	public List<Carts> getCartsById(Integer cid) {
		return daoref.getCartsById(cid);
	}
	
	
	/*@Override
	public List<Products> findByCategory(Enum cat) {
		
		return daoref.findByCategory(cat);
	}*/

	/*@Override
	public List<Products> findAll() {
		
		return daoref.findAll();
	}*/
	@Override
	public boolean checkDeliveryAvailability(Products product, int pincode) throws CapStoreException {

		return daorefAdmin.checkDeliveryAvailability(product, pincode);
	}


	@Override
	public Products findPById(Integer id) {
		return daorefCustomer.findPById(id);
	}


	@Override
	public void addFeedback(Feedbacks fb) {
		daorefCustomer.addFeedback(fb);
		
	}


	@Override
	public ArrayList<Feedbacks> showAllFeedbacks(int productId) {
		return daorefCustomer.productFeedback(productId);
	}


	@Override
	public feedbackdetails getfeedbackdetails(int id) {
		
		return daorefCustomer.getfeedbackdetails(id);
	}


	@Override
	public void deleteCoupon(int cust_id, String code) {
		// TODO Auto-generated method stub
		daorefCustomer.deleteCoupon(cust_id, code);
	}


	@Override
	public Customers getCustomer(int cid) {
		// TODO Auto-generated method stub
		return daorefCustomer.getCustomer(cid);
	}


	@Override
	public void createReferralCoupon(int cid) {
		// TODO Auto-generated method stub
		daoref.createReferralCoupon(cid);
	}


	@Override
	public ArrayList<Products> findSimilarProducts(int pid) {
		// TODO Auto-generated method stub
		return daorefCustomer.findSimilarProducts(pid);
	}


	@Override
	public void addCoupon(Date date, int amount, int customer_id) {
		// TODO Auto-generated method stub
		
	}
}
