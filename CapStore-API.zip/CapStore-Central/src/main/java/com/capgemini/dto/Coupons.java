package com.capgemini.dto;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name="coupons")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Coupons {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="coupon_id")
	private int couponId;
	@Column(name="coupon_code")
	private String couponCode;
	@Column(name="coupon_expirationDate")
	private Date couponExpirationDate;
	@Column(name="coupon_amount")
	private int couponAmount;
	@Column(name="customer_id")
	private int customerId;
	public Coupons() {
		// TODO Auto-generated constructor stub
	}
	
	public Coupons(String couponCode, Date couponExpirationDate, int couponAmount, int customerId) {
		super();
		this.couponCode = couponCode;
		this.couponExpirationDate = couponExpirationDate;
		this.couponAmount = couponAmount;
		this.customerId = customerId;
	}

	public int getCouponId() {
		return couponId;
	}
	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public Date getCouponExpirationDate() {
		return couponExpirationDate;
	}
	public void setCouponExpirationDate(Date couponExpirationDate) {
		this.couponExpirationDate = couponExpirationDate;
	}
	public int getCouponAmount() {
		return couponAmount;
	}
	public void setCouponAmount(int couponAmount) {
		this.couponAmount = couponAmount;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
}
