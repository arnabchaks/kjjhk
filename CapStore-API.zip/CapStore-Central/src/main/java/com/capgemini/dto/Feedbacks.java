package com.capgemini.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="feedbacks")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Feedbacks {
	@Id
	@Column(name = "feedback_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
		private int feedbackId;
	@Column(name = "feedback_message")
	private String feedbackMessage;
	@Column(name = "feedback_date")
	private Date feedbackDate;
	@Column(name = "feedback_rating")
	private double feedbackRating;
	@Column(name = "product_id")
	private int productId;
	@Column(name = "merchant_id")
	private int merchantId;
	@Column(name = "customer_id")
	private int customerId;
	
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getFeedbackMessage() {
		return feedbackMessage;
	}
	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}
	public Date getFeedbackDate() {
		return feedbackDate;
	}
	public void setFeedbackDate(Date feedbackDate) {
		this.feedbackDate = feedbackDate;
	}
	public double getFeedbackRating() {
		return feedbackRating;
	}
	public void setFeedbackRating(double feedbackRating) {
		this.feedbackRating = feedbackRating;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
}
