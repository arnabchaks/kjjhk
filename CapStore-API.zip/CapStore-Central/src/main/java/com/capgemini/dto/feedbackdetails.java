package com.capgemini.dto;


public class feedbackdetails {
	int id;
	long total;
	double avg;
	long star5;
	long star4;
	long star3;
	long star2;
	long star1;
	double star5p;
	double star4p;
	double star3p;
	double star2p;
	double star1p;
	

	public void calculatePercent(){
		star5p=((double)star5)/total*100;
		star4p=((double)star4)/total*100;
		star3p=((double)star3)/total*100;
		star2p=((double)star2)/total*100;
		star1p=((double)star1)/total*100;
		avg=(star5p*5+star4p*4+star3p*3+star2p*2+star1p*1)/100;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public long getTotal() {
		return total;
	}


	public void setTotal(long total) {
		this.total = total;
	}


	public double getAvg() {
		return avg;
	}


	public void setAvg(double avg) {
		this.avg = avg;
	}


	public long getStar5() {
		return star5;
	}


	public void setStar5(long star5) {
		this.star5 = star5;
	}


	public long getStar4() {
		return star4;
	}


	public void setStar4(long star4) {
		this.star4 = star4;
	}


	public long getStar3() {
		return star3;
	}


	public void setStar3(long star3) {
		this.star3 = star3;
	}


	public long getStar2() {
		return star2;
	}


	public void setStar2(long star2) {
		this.star2 = star2;
	}


	public long getStar1() {
		return star1;
	}


	public void setStar1(long star1) {
		this.star1 = star1;
	}


	public double getStar5p() {
		return star5p;
	}


	public void setStar5p(double star5p) {
		this.star5p = star5p;
	}


	public double getStar4p() {
		return star4p;
	}


	public void setStar4p(double star4p) {
		this.star4p = star4p;
	}


	public double getStar3p() {
		return star3p;
	}


	public void setStar3p(double star3p) {
		this.star3p = star3p;
	}


	public double getStar2p() {
		return star2p;
	}


	public void setStar2p(double star2p) {
		this.star2p = star2p;
	}


	public double getStar1p() {
		return star1p;
	}


	public void setStar1p(double star1p) {
		this.star1p = star1p;
	}
	
	
	
}
