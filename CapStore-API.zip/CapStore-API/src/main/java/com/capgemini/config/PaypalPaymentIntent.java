package com.capgemini.config;

public enum PaypalPaymentIntent {

	sale, authorize, order

}
