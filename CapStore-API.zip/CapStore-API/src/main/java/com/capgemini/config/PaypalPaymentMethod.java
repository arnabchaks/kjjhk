package com.capgemini.config;

public enum PaypalPaymentMethod {

	credit_card, paypal
	
}
