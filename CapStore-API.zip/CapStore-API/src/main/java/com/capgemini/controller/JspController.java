package com.capgemini.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.dto.Admin;
import com.capgemini.dto.CartListDummy;
import com.capgemini.dto.Carts;
import com.capgemini.dto.Customers;
import com.capgemini.dto.Merchants;
import com.capgemini.dto.ProductListDummy;
import com.capgemini.dto.Products;
import com.capgemini.dto.WishList;



@Controller
public class JspController {
	@RequestMapping("/")
	public String showWelcomePage(ModelMap map)
	{
		return "welcome";
	}
	@RequestMapping("/productsList")
	public String showProductsList(ModelMap map,@ModelAttribute("product") Products product)
	{
		System.out.println("Inside products List");
		RestTemplate restTemplate = new RestTemplate();
		ProductListDummy response = restTemplate.getForObject("http://localhost:9090/productsList", ProductListDummy.class);
		List<Products> products = response.getProducts();
		System.out.println(products);
		map.addAttribute("productsList", products);
		return "productsList";
	}
	@RequestMapping("/addProductpage")
	public String addProductpage(ModelMap map, @ModelAttribute("product") Products product){
         
		System.out.println("Inside addProductpage");
		 map.addAttribute("product", product);
		 return "productForm";
	}
	@RequestMapping("/editProduct")
	public String editProduct(@RequestParam("productId") Integer id, ModelMap map){
   
		System.out.println("ye has id:"+id);
		/*RestTemplate restTemplate = new RestTemplate();
		 
		System.out.println(product);
		
		restTemplate.postForObject("http://localhost:9090/updateproduct",id, String.class);*/

		RestTemplate restTemplate1 = new RestTemplate();
		Products obj = restTemplate1.getForObject("http://localhost:9090/findproduct?id="+id, Products.class);

		map.addAttribute("product", obj);
		
		return "productForm";
	}

	@RequestMapping("/deleteProduct")
	public String deleteProduct(@RequestParam("productId") String[] ids, ModelMap map , @ModelAttribute("product") Products product){
   
		RestTemplate restTemplate = new RestTemplate();
		 
		System.out.println(product);
		
		restTemplate.postForObject("http://localhost:9090/deleteproduct",ids, Arrays.class);

		RestTemplate restTemplate1 = new RestTemplate();
		ProductListDummy response = restTemplate1.getForObject("http://localhost:9090/displayAllProduct", ProductListDummy.class);
		List<Products> products = response.getProducts();
		System.out.println(products);
		map.addAttribute("productsList", products);
		return "ProductList";
	}
	@RequestMapping("/addProductToList")
	public String addProducttoList(ModelMap map, @ModelAttribute("product") Products product){

		if(product.getProductId()==-1){
			
			RestTemplate restTemplate = new RestTemplate();
			System.out.println("**insiode add Product");
			
			Products obj = restTemplate.postForObject("http://localhost:9090/addproduct", product, Products.class);
			 
		}
		else
		{
			RestTemplate rest = new RestTemplate();
			Products obj = rest.postForObject("http://localhost:9090/updateproduct", product, Products.class);
		}
			//map.addAttribute("product", obj);
            
			RestTemplate restTemplate1 = new RestTemplate();
			ProductListDummy response = restTemplate1.getForObject("http://localhost:9090/displayAllProduct", ProductListDummy.class);
			List<Products> products = response.getProducts();
			/*System.out.println(products);*/
			map.addAttribute("productsList", products);
			return "ProductList";
	}
	@RequestMapping("/productInfo")
	public String productInfo(ModelMap map, Integer id)
	{
		RestTemplate restTemplate = new RestTemplate();
		Products productnew = restTemplate.getForObject("http://localhost:9090/findProduct?id="+id, Products.class);
		map.addAttribute("product", productnew);
		return "productInfo";
	}
	@RequestMapping("/addToWishList")
	public String addToWishList(ModelMap map, @RequestParam(value="pid") String pid, @RequestParam(value="cid") String cid)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside Add to Wish List");
		WishList wl = new WishList();
		wl.setProductId(Integer.parseInt(pid));
		wl.setCustomerId(Integer.parseInt(cid));
		WishList wishlistnew = restTemplate.postForObject("http://localhost:9090/addToWishList", wl, WishList.class);
		System.out.println(wishlistnew);
		Products productnew = restTemplate.getForObject("http://localhost:9090/findProduct?id="+pid, Products.class);
		map.addAttribute("product", productnew);
		//map.addAttribute("wishlistList", wishlistnew);
		return "productInfo";
	}
	
	@RequestMapping("/viewWishList")
	public String viewWishList(ModelMap map, Integer cid)
	{
		System.out.println("111");
		System.out.println(cid);
		RestTemplate restTemplate = new RestTemplate();
		WishListDummy response = restTemplate.getForObject("http://localhost:9090/WishList?cid="+cid, WishListDummy.class);
		System.out.println("222");
		List<WishList> wishlist = response.getList();
		/*Products productnew = restTemplate.getForObject("http://localhost:9090/findProduct?id="+pid, Products.class);
		map.addAttribute("product", productnew);*/
		//System.out.println(carts);
		map.addAttribute("wishlistList", wishlist);
	
		return "viewWishList";
	}

	
	
	/*@RequestMapping("/productInfo")
	public String productInfo(ModelMap map, Integer id, Integer cid)
	{
		RestTemplate restTemplate = new RestTemplate();
		Products productnew = restTemplate.getForObject("http://localhost:9090/findProduct?id="+id, Products.class);
		map.addAttribute("customerId", cid);
		map.addAttribute("product", productnew);
		return "productInfo";
	}*/
	/*@RequestMapping("/addToCart")
	public String addToCart(ModelMap map, Integer pid, Integer mid)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside Add to Cart");
		Carts cart = new Carts();
		cart.setProductId(pid);
		cart.setMerchantId(mid);
		Carts cartnew = restTemplate.postForObject("http://localhost:9090/addToCart", cart, Carts.class);
//		Carts cartnew= restTemplate.getForObject("http://localhost:9090/addToCart?pid="+pid"?mid=2", Carts.class);
		System.out.println(cartnew);
		map.addAttribute("cart", cartnew);
		return "viewCart";
	}*/
	
	
	/*@RequestMapping("/addToCart")
	public String addToCart(ModelMap map, @RequestParam(value="pid") String pid, @RequestParam(value="mid") String mid, @RequestParam(value="cid") String cid)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside Add to Cart");
		Carts cart = new Carts();
		cart.setProductId(Integer.parseInt(pid));
		cart.setMerchantId(Integer.parseInt(mid));
		cart.setCustomerId(Integer.parseInt(cid));
		Carts cartnew = restTemplate.postForObject("http://localhost:9090/addToCart", cart, Carts.class);
		System.out.println(cartnew);
		map.addAttribute("cart", cartnew);
		return "viewCart";
	}*/
	
	@RequestMapping("/addToCart")
	public String addToCart(ModelMap map, @RequestParam(value="pid") String pid, @RequestParam(value="mid") String mid, @RequestParam(value="cid") String cid)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside Add to Cart");
		Carts cart = new Carts();
		cart.setProductId(Integer.parseInt(pid));
		cart.setMerchantId(Integer.parseInt(mid));
		cart.setCustomerId(Integer.parseInt(cid));
		Carts cartnew = restTemplate.postForObject("http://localhost:9090/addToCart", cart, Carts.class);
		System.out.println(cartnew);
		Products productnew = restTemplate.getForObject("http://localhost:9090/findProduct?id="+pid, Products.class);
		map.addAttribute("product", productnew);
		//map.addAttribute("cart", cartnew);
		return "productInfo";
	}
	
	@RequestMapping("/viewCart")
	public String viewCart(ModelMap map, Integer cid)
	{
		System.out.println("111");
		System.out.println(cid);
		RestTemplate restTemplate = new RestTemplate();
		CartListDummy response = restTemplate.getForObject("http://localhost:9090/cartsList?cid="+cid, CartListDummy.class);
		System.out.println("222");
		List<Carts> carts = response.getCarts();
		double total=0;
		for(Carts c:carts){
			total += c.getTotalPrice();
		}
		map.addAttribute("total", total);
		System.out.println(carts);
		map.addAttribute("cartList", carts);
	
		return "viewCart";
	}
	
	@RequestMapping("/updateQuantity")
	public String updateQuantity(ModelMap map,@ModelAttribute("cart") Carts cart)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside Update Quantity");
		Carts cartnew = restTemplate.postForObject("http://localhost:9090/updateQuantity", cart, Carts.class);
//		Carts cartnew = restTemplate.getForObject("http://localhost:9090/updateQuantity?csn"+csn, Carts.class);
		CartListDummy response = restTemplate.getForObject("http://localhost:9090/cartsList?cid="+cart.getCustomerId(), CartListDummy.class);
		List<Carts> carts = response.getCarts();
		double total=0;
		for(Carts cnew : carts){
			total += cnew.getTotalPrice();
		}
		map.addAttribute("total", total);
		map.addAttribute("cartList", carts);
		return "viewCart";
	}
	
	@RequestMapping("/deleteFromCart")
	public String deleteFromCart(ModelMap map,  @ModelAttribute("cart") Carts cart, Integer cid, Integer csn)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside deleteFromCart");
		System.out.println("This is also something" + csn);
		Carts cartnew = restTemplate.postForObject("http://localhost:9090/deleteFromCart?csn="+csn, cart, Carts.class);
		CartListDummy response = restTemplate.getForObject("http://localhost:9090/cartsList?cid="+cid, CartListDummy.class);
		List<Carts> carts = response.getCarts();
		double total=0;
		for(Carts cnew : carts){
			total += cnew.getTotalPrice();
		}
		map.addAttribute("total", total);
		map.addAttribute("cartList", carts);
		return "viewCart";
	}
	
	@RequestMapping("/deleteFromWishList")
	public String deleteFromCart(ModelMap map,  @ModelAttribute("wishlist") WishList w, Integer cid, Integer csn)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside deleteFromwishlist");
		System.out.println("This is also something" + csn);
		WishList wnew = restTemplate.postForObject("http://localhost:9090/deleteFromWishList?csn="+csn, w, WishList.class);
		WishListDummy response = restTemplate.getForObject("http://localhost:9090/WishList?cid="+cid, WishListDummy.class);
		List<WishList> wishlist = response.getList();
		
		map.addAttribute("wishlistList", wishlist);
		return "viewWishList";
	}
	
	@RequestMapping("/continueShopping")
	public String continueShopping(ModelMap map,  @ModelAttribute("wishlist") WishList w)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside continueShopping");
		Customers customer1 = restTemplate.getForObject("http://localhost:9090/GetCustomer?cid="+w.getCustomerId(),Customers.class);
		map.addAttribute("customer", customer1);
		ProductListDummy response = restTemplate.getForObject("http://localhost:9090/productsList", ProductListDummy.class);
		List<Products> products = response.getProducts();
		System.out.println(products);
		map.addAttribute("productList", products);
		return "customerHomePage";
	}
	
	@RequestMapping("/Continue")
	public String Continue(ModelMap map,@ModelAttribute("cart") Carts c)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside continue ");
		System.out.println(c.getCustomerId());
		Customers customer1 = restTemplate.getForObject("http://localhost:9090/GetCustomer?cid="+c.getCustomerId(),Customers.class);
		System.out.println(customer1);
		map.addAttribute("customer", customer1);
		ProductListDummy response = restTemplate.getForObject("http://localhost:9090/productsList", ProductListDummy.class);
		List<Products> products = response.getProducts();
		System.out.println(products);
		map.addAttribute("productList", products);
		return "customerHomePage";
	}
		
	/*@RequestMapping("/viewCart")
	public String viewCart(ModelMap map, Integer cid)
	{
		System.out.println("111");
		System.out.println(cid);
		RestTemplate restTemplate = new RestTemplate();
		CartListDummy response = restTemplate.getForObject("http://localhost:9090/cartsList?cid="+cid, CartListDummy.class);
		System.out.println("222");
		List<Carts> carts = response.getCarts();
		double total=0;
		for(Carts c:carts){
			total += c.getTotalPrice();
		}
		map.addAttribute("total", total);
		System.out.println(carts);
		map.addAttribute("cartList", carts);
	
		return "viewCart";
	}
	
	@RequestMapping("/updateQuantity")
	public String updateCart(ModelMap map, Integer csn)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside Update Quantity");
//		Carts cartnew = restTemplate.postForObject("http://localhost:9090/updateQuantity", cart, Carts.class);
		CartListDummy response = restTemplate.getForObject("http://localhost:9090/updateQuantity?csn="+csn, CartListDummy.class);
		List<Carts> carts = response.getCarts();
		double total=0;
		for(Carts c:carts){
			total += c.getTotalPrice();
		}
		map.addAttribute("total", total);
		map.addAttribute("cartList", carts);
		return "viewCart";
	}
	
	@RequestMapping("/deleteFromCart")
	public String deleteFromCart(ModelMap map,  @ModelAttribute("cart") Carts cart)
	{
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside deleteFromCart");
		Carts cartnew = restTemplate.postForObject("http://localhost:9090/deleteFromCart", cart, Carts.class);
		map.addAttribute("cart", cartnew);
		return "viewCart";
	}*/
	
	/*@RequestMapping("/checkout")
	public String checkout(ModelMap map,Integer amount)
	{
		RestTemplate restTemplate = new RestTemplate();
		Integer d = restTemplate.getForObject("http://localhost:5000/checkout?amount="+amount, Integer.class);
		map.addAttribute("amount", amount);
		return "viewCart";
	}*/
	
/*	@RequestMapping("/ManageMerchants")
	public String  manageMerchants(ModelMap map, @ModelAttribute("merchant") Merchants merchant){
		 map.addAttribute("merchant", merchant);
		 return "MerchantList";
   }*/
	
/*	@RequestMapping("/signUpPage")
	public String showSignUpPage(ModelMap map, @ModelAttribute("customer") Customers cus)
	{
		map.addAttribute("customer", cus);
		return "signUpPage";
	}*/
	
	/*@RequestMapping("/addProduct")
	public String  addProduct(ModelMap map,@ModelAttribute("merchant") Merchants merchant)
	{
		RestTemplate restTemplate = new RestTemplate();
		return "addProduct";
	}*/
	
	@RequestMapping("/addProduct")
	public String addProducttoListNew(ModelMap map, @ModelAttribute("product") Products product){

		if(product.getProductId()==-1){
			
			RestTemplate restTemplate = new RestTemplate();
			System.out.println("**insiode add Product");
			
			Products obj = restTemplate.postForObject("http://localhost:9090/addproduct", product, Products.class);
			 
		}
		else
		{
			RestTemplate rest = new RestTemplate();
			Products obj = rest.postForObject("http://localhost:9090/updateproduct", product, Products.class);
		}
			//map.addAttribute("product", obj);
            
			RestTemplate restTemplate1 = new RestTemplate();
			ProductListDummy response = restTemplate1.getForObject("http://localhost:9090/displayAllProduct", ProductListDummy.class);
			List<Products> products = response.getProducts();
			/*System.out.println(products);*/
			map.addAttribute("productsList", products);
			return "ProductList";
	}
	
	@ModelAttribute("admin")
	Admin getAdmin() {
		Admin ac = new Admin();	
		return ac;
	}
	
	@ModelAttribute("merchant")
	Merchants getMerchant() {
		
		Merchants m = new Merchants();
		return m;
	}
	
	@ModelAttribute("product")
	Products getProduct() {
		Products p = new Products();	
		return p;
	}
	
	@ModelAttribute("customer")
	Customers getCustomer() {
		Customers ac = new Customers();	
		return ac;
	}
	
	@ModelAttribute("cart")
	Carts getCart()
	{
		return new Carts();
	}
}
