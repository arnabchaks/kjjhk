package com.capgemini.controller;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.dto.Admin;
import com.capgemini.dto.Coupons;
import com.capgemini.dto.CustomerDummy;
import com.capgemini.dto.Customers;
import com.capgemini.dto.MerchantDummy;
import com.capgemini.dto.Merchants;
import com.capgemini.dto.ProductListDummy;
import com.capgemini.dto.Products;

@Controller
public class JspControllerAdmin {
	/*
	 * @RequestMapping("/adminlogin") public String showAdminLoginPage(ModelMap
	 * map) { return "adminLogin"; }
	 * 
	 * @RequestMapping("/adminlogincheck") public String
	 * adminLoginCheck(ModelMap map,@Valid @ModelAttribute("admin") Admin admin,
	 * BindingResult error) { if(error.hasErrors()) { return "adminLogin"; }
	 * else { RestTemplate restTemplate = new RestTemplate(); Admin message =
	 * restTemplate.postForObject("http://localhost:9090/loginAdmin",admin,
	 * Admin.class); System.out.println(message);
	 * if(message.getAdminPswd().equals("dummy")) { map.addAttribute("error",
	 * "Invalid Credentials"); map.addAttribute("admin", admin); return
	 * "adminLogin"; } else { map.addAttribute("admin", message); return
	 * "adminHomePage"; } } }
	 */
	@RequestMapping("/adminlogin")
	public String showAdminLoginPage(ModelMap map, @ModelAttribute("admin") Admin admin) {

		map.addAttribute("admin", admin);
		return "adminlogin";
	}

	@RequestMapping("/adminHomePage")
	public String returnAdminHomePage(ModelMap map, @ModelAttribute("admin") Admin admin) {

		map.addAttribute("admin", admin);
		return "adminHomePage";
	}

	@RequestMapping("/adminlogincheck")
	public String adminLoginCheck(ModelMap map, @Valid @ModelAttribute("admin") Admin admin, BindingResult error) {

		if (error.hasErrors()) {
			System.out.println(error.toString());
			map.addAttribute("admin", admin);
			return "adminlogin";
		}

		RestTemplate restTemplate = new RestTemplate();

		Admin message = restTemplate.postForObject("http://localhost:9090/loginAdmin", admin, Admin.class);
		if (message.getAdminPswd().equals("dummy")) {
			map.addAttribute("error", "Invalid Credentials");
//			return "errorPage";
			return "adminlogin";
		} else {
			map.addAttribute("adminDetails", message);
			return "adminHomePage";
		}
	}

	@RequestMapping("/viewCustomers")
	public String viewCustomers(ModelMap map) {

		System.out.println("Inside products List");
		RestTemplate restTemplate = new RestTemplate();
		CustomerDummy response = restTemplate.getForObject("http://localhost:9090/getAllCustomer", CustomerDummy.class);
		List<Customers> customers = response.getCustomers();
		/* System.out.println(products); */
		map.addAttribute("customerList", customers);
		return "customerdummypage";
	}

	@RequestMapping("/ManageMerchants")
	public String manageMerchants(ModelMap map, @ModelAttribute("merchant") Merchants merchant) {

		RestTemplate restTemplate = new RestTemplate();

		MerchantDummy message = restTemplate.getForObject("http://localhost:9090/displayAllMerchant",
				MerchantDummy.class);
		List<Merchants> list = message.getMerchants();

		map.addAttribute("merchantList", list);
		return "MerchantList";

	}

	@RequestMapping("/viewMerchants")
	public String merchantOperations(ModelMap map) {

		return "merchantOperations";
	}

	@RequestMapping("/deleteMerchant")
	public String deleteMerchant(@RequestParam("merchantId") String[] ids, ModelMap map,
			@ModelAttribute("merchant") Merchants merchant) {

		RestTemplate restTemplate = new RestTemplate();

		/* System.out.println(product); */

		restTemplate.postForObject("http://localhost:9090/deletemerchant", ids, Arrays.class);

		RestTemplate restTemplate1 = new RestTemplate();
		MerchantDummy response = restTemplate1.getForObject("http://localhost:9090/displayAllMerchant",
				MerchantDummy.class);
		List<Merchants> merchants = response.getMerchants();
		System.out.println(merchants);
		map.addAttribute("merchantList", merchants);
		return "MerchantList";
	}

	@RequestMapping("/editMerchant")
	public String editMerchant(@RequestParam("merchantId") Integer id, ModelMap map) {

		System.out.println("ye has id:" + id);
		/*
		 * RestTemplate restTemplate = new RestTemplate();
		 * 
		 * System.out.println(product);
		 * 
		 * restTemplate.postForObject("http://localhost:9090/updateproduct",id,
		 * String.class);
		 */

		RestTemplate restTemplate1 = new RestTemplate();
		Merchants obj = restTemplate1.getForObject("http://localhost:9090/findmerchant?id=" + id, Merchants.class);

		map.addAttribute("merchant", obj);

		return "merchantForm";
	}

	@RequestMapping("/viewProductListfromAdmin")
	public String showProductsListfromAdmin(ModelMap map, @ModelAttribute("product") Products product) {
		System.out.println("Inside products List");
		RestTemplate restTemplate = new RestTemplate();
		ProductListDummy response = restTemplate.getForObject("http://localhost:9090/displayAllProduct",
				ProductListDummy.class);
		List<Products> products = response.getProducts();
		System.out.println(products);
		map.addAttribute("productsList", products);
		return "ProductListAdmin";
	}

	@RequestMapping("/addMerchantpagefromAdmin")
	public String addMerchantsfromAdmin(ModelMap map, @Valid @ModelAttribute("merchant") Merchants merchant,
			BindingResult error) {

		System.out.println(error.toString());
		map.addAttribute("merchant", merchant);
		return "adminMerchant";

		/*
		 * RestTemplate restTemplate = new RestTemplate();
		 * 
		 * Merchants message =
		 * restTemplate.postForObject("http://localhost:9090/addmerchant",
		 * merchant, Merchants.class); map.addAttribute("merchant", message);
		 * return "MerchantList";
		 */

	}
	
	@RequestMapping("/addCouponsPage")
	public String showaddCouponPage(ModelMap map,@ModelAttribute("coupons") Coupons c){
			
			map.addAttribute("coupons", c);
			
				return "generatingcouponPage";
	}
	@RequestMapping("/generateCoupon")
	public String generateCoupons(ModelMap map,@ModelAttribute("coupons") Coupons c,@RequestParam("selDate") String selDate) throws ParseException{
	System.out.println(c.getCouponAmount()+"***"+c.getCouponCode()+"**"+c.getCustomerId());
	
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	LocalDate localDate = LocalDate.parse(selDate, formatter);
	System.out.println(localDate);
	  //**************
	
	RestTemplate restTemplate = new RestTemplate();
	
	c.setCouponExpirationDate(java.sql.Date.valueOf(localDate));
	
	Coupons successfullAdd = restTemplate.postForObject("http://localhost:9090/generateCoupon",c, Coupons.class);
	map.addAttribute("message", successfullAdd.getCouponCode()+"of Amount "+successfullAdd.getCouponAmount()+" has been added successfully!");
	return "adminHomePage"	;
		
	}

	@ModelAttribute("admin")
	Admin getAdmin() {
		Admin ac = new Admin();
		return ac;
	}

	@ModelAttribute("merchant")
	Merchants getMerchant() {

		Merchants m = new Merchants();
		return m;
	}

	@ModelAttribute("product")
	Products getProduct() {
		Products p = new Products();
		return p;
	}

	@ModelAttribute("customer")
	Customers getCustomer() {
		Customers ac = new Customers();
		return ac;
	}
	@ModelAttribute("coupons")
	Coupons getCoupons() {
		Coupons c = new Coupons();	
		return c;
	}

}
