package com.capgemini.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.dto.Admin;
import com.capgemini.dto.Customers;
import com.capgemini.dto.MerchantDummy;
import com.capgemini.dto.Merchants;
import com.capgemini.dto.ProductListDummy;
import com.capgemini.dto.Products;


@Controller
public class JspControllerMerchant {

	/*@RequestMapping("/merchantlogin")
	public String showMerchantLoginPage(ModelMap map)
	{
		return "merchantLogin";
	}
	@RequestMapping("/merchantlogincheck")
	public String merchantLoginCheck(ModelMap map,@Valid @ModelAttribute("merchant") Merchants merchant, BindingResult error){
	{
		if(error.hasErrors())
		{
			map.addAttribute("merchant", merchant);
			return "merchantLogin";
		}
		else
		{
			RestTemplate restTemplate = new RestTemplate();
			Merchants merchant1 = restTemplate.postForObject("http://localhost:9090/loginMerchant",merchant,Merchants.class);
			if(merchant1.getMerchantPswd().equals("dummy"))
			{
				map.addAttribute("error", "Invalid Credentials");
				map.addAttribute("merchant", merchant);
				return "merchantLogin";
			}
			else
			{
				map.addAttribute("merchant", merchant1);
				return "merchantHomePage";
			}
		}}
	}*/
	@RequestMapping("/merchantlogincheck")
	public String  merchantLoginCheck(ModelMap map,@Valid @ModelAttribute("merchant") Merchants merchant, BindingResult error){
		
		System.out.println("fgyjknklhnkjs");
		if(error.hasErrors())
		{
			System.out.println(error.toString());
			map.addAttribute("merchant", merchant);
			return "merchantLogin";
		}
				
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("**insiode jsp controller");
		Merchants obj = restTemplate.postForObject("http://localhost:9090/loginMerchant",merchant, Merchants.class);

		if(obj==null){
			
		return "MerchantApproval";
		}
	//	System.out.println("after Central***** check JspHandler***");
		else{
		 map.addAttribute("merchant", obj);
		 return "merchantHomePage";
        }
	}
	@RequestMapping("/merchantHomePage")
	public String returnMerchantHomePage(ModelMap map, @ModelAttribute("merchant") Merchants merchant){
		 map.addAttribute("merchant", merchant);
		return "merchantHomePage";
	}
	@RequestMapping("/merchantlogin")
	public String showMerchantLoginPage(ModelMap map){
		
		
		return "merchantLogin";
	}
	@RequestMapping("/MerchantsignUpPage")
	public String showMerchantSignUpPage(ModelMap map, @ModelAttribute("merchant") Merchants mer){
		System.out.println("Inside Merchant Sign Up");
//		map.addAttribute("merchant", mer);
		return "merchantSingUpPage";
	}
	

	@RequestMapping("/viewProductList")
	public String showProductsList(ModelMap map,@ModelAttribute("product") Products product)
	{
		System.out.println("Inside products List");
		RestTemplate restTemplate = new RestTemplate();
		ProductListDummy response = restTemplate.getForObject("http://localhost:9090/displayAllProduct", ProductListDummy.class);
		List<Products> products = response.getProducts();
		System.out.println(products);
		map.addAttribute("productsList", products);
		return "ProductList";
	}
	@RequestMapping("/addmerchant")
	public String addMerchant(ModelMap map, @ModelAttribute("merchant") Merchants merchant){
System.out.println(merchant.getMerchantFlag());
		if(merchant.getMerchantId()==-1){
			RestTemplate restTemplate = new RestTemplate();
			/*System.out.println("**inside add Merchant");*/
			System.out.println(merchant);
			Merchants obj = restTemplate.postForObject("http://localhost:9090/addmerchant", merchant, Merchants.class);
			
			 
		}
		else
		{
			RestTemplate rest = new RestTemplate();
			Merchants obj = rest.postForObject("http://localhost:9090/updateMerchant",merchant, Merchants.class);
			System.out.println(obj.getMerchantFlag());
		}
			//map.addAttribute("product", obj);
            
			RestTemplate restTemplate1 = new RestTemplate();
			MerchantDummy response = restTemplate1.getForObject("http://localhost:9090/displayAllMerchant", MerchantDummy.class);
			List<Merchants> merchants = response.getMerchants();
			System.out.println(merchants);
			map.addAttribute("merchantList", merchants);
			return "MerchantList";
	}
	
	
	@RequestMapping("/merchantsignUp")
	public String signUpMerchant(ModelMap map,@Valid @ModelAttribute("merchant") Merchants mer, BindingResult error){
	
		if(error.hasErrors())
		{
			System.out.println(error.toString());
			map.addAttribute("merchant", mer);
			return "merchantSingUpPage";
		}
        RestTemplate restTemplate = new RestTemplate();
		
		 Merchants message = restTemplate.postForObject("http://localhost:9090/addmerchant",mer, Merchants.class);
		 map.addAttribute("merDetails", message);
		 return "MerchantApproval";
		 
	}
	@ModelAttribute("admin")
	Admin getAdmin() {
		Admin ac = new Admin();	
		return ac;
	}
	
	@ModelAttribute("merchant")
	Merchants getMerchant() {
		
		Merchants m = new Merchants();
		return m;
	}
	
	@ModelAttribute("product")
	Products getProduct() {
		Products p = new Products();	
		return p;
	}
	
	@ModelAttribute("customer")
	Customers getCustomer() {
		Customers ac = new Customers();	
		return ac;
	}
}
