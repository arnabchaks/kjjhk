package com.capgemini.dto;

public class WishList {
	private int wishlistId;
	
	public int getwishlistId() {
		return wishlistId;
	}
	public void setwishlistId(int wishlistId) {
		this.wishlistId = wishlistId;
	}
}
