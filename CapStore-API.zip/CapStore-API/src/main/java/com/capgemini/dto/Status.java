package com.capgemini.dto;

public enum Status {

	processing,
	delivered,
	returned,
}
