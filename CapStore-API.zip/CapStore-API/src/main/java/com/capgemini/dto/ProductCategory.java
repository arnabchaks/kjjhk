package com.capgemini.dto;

public enum ProductCategory {

	BOOKS,
	ELECTRONICS,
	CLOTHING,
	FURNITURE
}
