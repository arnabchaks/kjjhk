package com.capgemini.dto;

import java.util.ArrayList;
import java.util.List;

public class FeedbackWrapper {
	   private List<Feedbacks> feedbacks;

	public List<Feedbacks> getFeedbacks() {
		return feedbacks;
	}

	public void setFeedbacks(List<Feedbacks> feedbacks) {
		this.feedbacks = feedbacks;
	}
	   public FeedbackWrapper() {
		   feedbacks = new ArrayList<>();
	}

}
